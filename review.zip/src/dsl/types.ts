import type { JsonObject, JsonValue } from '../utils/json.js';

export type StepId = string;
export type PathRef = string;
export type StepType = 'PROCESS' | 'EFFECT' | 'WAIT' | 'TERMINAL';
export type ExecutableProcessSubtype = 'RULES' | 'MAPPINGS' | 'DECISIONS';
export type RoutingProcessSubtype = 'ROUTE' | 'SWITCH';
export type ProcessStepSubtype = ExecutableProcessSubtype | RoutingProcessSubtype;
export type EffectStepSubtype = 'COMMAND' | 'CALL';
export type WaitStepSubtype = 'MESSAGE';
export type TerminalResultStatus = 'COMPLETE' | 'FAIL';

export interface InputRefObject {
  [key: string]: PathRef | InputRefObject;
}

export type InputRef = PathRef | InputRefObject;

export interface TerminalResult {
  status: TerminalResultStatus;
  outcome: string;
  [key: string]: JsonValue;
}

export interface FlowDefinition {
  id: string;
  version: string;
  entryStepId: StepId;
  title?: string;
  description?: string;
  metadata?: JsonObject;
  steps: Record<StepId, StepDefinition>;
}

export interface StepDefinitionBase {
  id: StepId;
  type: StepType;
  subtype: string;
  title?: string;
  description?: string;
  metadata?: JsonObject;
}

export interface ExecutableProcessStepDefinition extends StepDefinitionBase {
  type: 'PROCESS';
  subtype: ExecutableProcessSubtype;
  artefactId: string;
  inputRef: InputRef;
  outputRef: PathRef;
  nextStepId: StepId;
}

export interface RouteStepDefinition extends StepDefinitionBase {
  type: 'PROCESS';
  subtype: 'ROUTE';
  factRef: PathRef;
  cases: Record<string, StepId>;
  defaultNextStepId: StepId;
}

export interface SwitchStepDefinition extends StepDefinitionBase {
  type: 'PROCESS';
  subtype: 'SWITCH';
  decisionSetId: string;
  cases: Record<string, StepId>;
  defaultNextStepId: StepId;
}

export interface EffectStepDefinition extends StepDefinitionBase {
  type: 'EFFECT';
  subtype: EffectStepSubtype;
  operationId: string;
  inputRef: InputRef;
  nextStepId: StepId;
  onErrorStepId?: StepId;
  onTimeoutStepId?: StepId;
}

export interface WaitStepDefinition extends StepDefinitionBase {
  type: 'WAIT';
  subtype: 'MESSAGE';
  sourceStepId: StepId;
  nextStepId: StepId;
  onErrorStepId: StepId;
  onTimeoutStepId: StepId;
}

export interface TerminalStepDefinition extends StepDefinitionBase {
  type: 'TERMINAL';
  subtype: TerminalResultStatus;
  result: TerminalResult;
}

export type ProcessStepDefinition =
  | ExecutableProcessStepDefinition
  | RouteStepDefinition
  | SwitchStepDefinition;

export type StepDefinition =
  | ProcessStepDefinition
  | EffectStepDefinition
  | WaitStepDefinition
  | TerminalStepDefinition;

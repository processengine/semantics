export type FlowValidationCode =
  | 'FLOW_ID_REQUIRED'
  | 'FLOW_VERSION_REQUIRED'
  | 'FLOW_STEPS_EMPTY'
  | 'FLOW_ENTRY_STEP_NOT_FOUND'
  | 'FLOW_REQUIRED_FIELD_MISSING'
  | 'FLOW_FIELD_FORBIDDEN'
  | 'FLOW_INVALID_TYPE'
  | 'FLOW_INVALID_SUBTYPE'
  | 'FLOW_STEP_ID_MISMATCH'
  | 'FLOW_STEP_REF_NOT_FOUND'
  | 'FLOW_ORPHAN_STEP'
  | 'FLOW_TERMINAL_NOT_REACHABLE'
  | 'FLOW_WAIT_BRANCH_MISSING'
  | 'FLOW_WAIT_SOURCE_INVALID'
  | 'FLOW_ROUTE_DEFAULT_MISSING'
  | 'FLOW_SWITCH_DEFAULT_MISSING'
  | 'FLOW_TERMINAL_RESULT_INVALID'
  | 'FLOW_PATH_SYNTAX_INVALID'
  | 'FLOW_WRITE_NAMESPACE_FORBIDDEN';

export type FlowRuntimeCode =
  | 'FLOW_STATE_INVALID'
  | 'FLOW_FLOW_MISMATCH'
  | 'FLOW_STEP_NOT_FOUND'
  | 'FLOW_STEP_MISMATCH'
  | 'FLOW_TERMINAL_MISUSED'
  | 'FLOW_REDUCE_INVALID_TYPE'
  | 'FLOW_APPLY_INVALID_TYPE'
  | 'FLOW_RESUME_INVALID_TYPE'
  | 'FLOW_STEP_ID_MISMATCH'
  | 'FLOW_PATH_NOT_RESOLVED'
  | 'FLOW_ROUTING_VALUE_INVALID'
  | 'FLOW_DECISION_NOT_RESOLVED'
  | 'FLOW_RESULT_SHAPE_INVALID'
  | 'FLOW_MIXED_RESULT'
  | 'FLOW_REQUEST_ID_MISSING';

export type FlowCompileCode = 'FLOW_PREPARE_INVALID';
export type FlowErrorCode = FlowValidationCode | FlowRuntimeCode | FlowCompileCode;

export interface ValidationIssue {
  code: FlowValidationCode;
  message: string;
  path?: string;
  details?: Record<string, unknown>;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationIssue[];
  warnings: ValidationIssue[];
}

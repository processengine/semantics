# `@processengine/flows` Specification

## Purpose

`flows` is the process-semantics runtime of ProcessEngine. It validates Flow DSL, prepares immutable flow artifacts, normalizes the current step, and applies process-state transitions.

`flows` does not execute runtime modules, perform Host side effects, persist state, generate `requestId`, or own retry/scheduling logic.

## Public API

```ts
validateFlow(flow, options?) -> ValidationResult
prepareFlow(flow, options?)  -> PreparedFlow

plan(preparedFlow, state)                        -> NormalizedStep
reduce(step, state, output)                      -> ProcessState
apply(preparedFlow, state, stepId, effectResult) -> ProcessState
resume(preparedFlow, state, stepId, waitResult)  -> ProcessState
```

`validateFlow(...)` never throws for ordinary DSL problems.  
`prepareFlow(...)` throws `XCompileError`.  
Runtime methods throw `XRuntimeError`.

## Boundary with `process` and Host

- `flows` owns DSL semantics, `PreparedFlow`, `plan`, `reduce`, `apply`, `resume`
- `process` owns execution of executable `PROCESS` steps: `RULES`, `MAPPINGS`, `DECISIONS`
- Host owns persistence, execution loop, side effects, transport, recovery, `requestId`

Host must not resolve `inputRef`, `factRef`, or SWITCH outcome logic manually.

## Flow DSL

### Root shape

```json
{
  "id": "request.processing",
  "version": "2026-04-09",
  "entryStepId": "validate_input",
  "steps": {
    "validate_input": { "...": "..." }
  }
}
```

Rules:
- `id` required
- `version` required
- `entryStepId` must reference an existing step
- `steps` must be a non-empty object
- object key must match `step.id`

### Step families

| type | subtype |
|------|---------|
| `PROCESS` | `RULES`, `MAPPINGS`, `DECISIONS`, `ROUTE`, `SWITCH` |
| `EFFECT` | `COMMAND`, `CALL` |
| `WAIT` | `MESSAGE` |
| `TERMINAL` | `COMPLETE`, `FAIL` |

No subtype-less step exists in the public contract.

### Executable PROCESS

Required fields:
- `id`
- `type: "PROCESS"`
- `subtype`
- `artefactId`
- `inputRef`
- `outputRef`
- `nextStepId`

`outputRef` writable zones:
- `$.context.checks...`
- `$.context.facts...`
- `$.context.decisions...`

Subject convention:
- `RULES` write to `context.checks`
- `MAPPINGS` write to `context.facts`
- `DECISIONS` write to `context.decisions`

### ROUTE

Required fields:
- `factRef`
- `cases`
- `defaultNextStepId`

Runtime semantics:
- reads `factRef`
- missing path is runtime violation
- scalar result is normalized to case key
- object/array routing value is runtime violation

### SWITCH

Required fields:
- `decisionSetId`
- `cases`
- `defaultNextStepId`

Runtime semantics:
- reads `context.decisions[decisionSetId].outcome`
- missing decision record or missing `outcome` is runtime violation

### EFFECT

Required fields:
- `id`
- `type: "EFFECT"`
- `subtype`
- `operationId`
- `inputRef`
- `nextStepId`

Optional:
- `onErrorStepId`
- `onTimeoutStepId`

`operationId` is Host dispatch identifier. It is not an `artefactId`.

### WAIT

`WAIT/MESSAGE` is the canonical wait-step form.

Required fields:
- `id`
- `type: "WAIT"`
- `subtype: "MESSAGE"`
- `sourceStepId`
- `nextStepId`
- `onErrorStepId`
- `onTimeoutStepId`

`sourceStepId` must reference an EFFECT step.

### TERMINAL

Required fields:
- `id`
- `type: "TERMINAL"`
- `subtype`
- `result`

`result.status` must match TERMINAL subtype.

## Prepared Flow

`prepareFlow(...)` returns `PreparedFlow`.

Guarantees:
- separate from raw flow
- compile/prepare-checked
- immutable
- JSON-safe / transport-safe
- ready for `plan`, `reduce`, `apply`, `resume`

Internal `PreparedFlow` structure is implementation-private and intentionally not normative.

## Process State

Canonical root shape:

```json
{
  "processId": "proc_001",
  "id": "request.processing",
  "status": "ACTIVE",
  "currentStepId": "validate_input",
  "currentStepType": "PROCESS",
  "currentStepSubtype": "RULES",
  "context": {
    "input": {},
    "checks": {},
    "facts": {},
    "decisions": {},
    "steps": {},
    "effects": {}
  },
  "history": [],
  "result": null,
  "meta": {}
}
```

Status values:
- `ACTIVE`
- `WAITING`
- `COMPLETE`
- `FAIL`

Terminal processes must not be advanced again.

## Normalized steps

### Executable PROCESS

```json
{
  "id": "validate_input",
  "type": "PROCESS",
  "subtype": "RULES",
  "artefactId": "process.validate",
  "input": {}
}
```

### ROUTE

```json
{
  "id": "route_validation",
  "type": "PROCESS",
  "subtype": "ROUTE",
  "selectedNextStepId": "send_command"
}
```

### SWITCH

```json
{
  "id": "switch_review",
  "type": "PROCESS",
  "subtype": "SWITCH",
  "selectedNextStepId": "finish_complete"
}
```

### EFFECT

```json
{
  "id": "send_command",
  "type": "EFFECT",
  "subtype": "COMMAND",
  "operationId": "remote.submit",
  "input": {}
}
```

### WAIT

```json
{
  "id": "wait_response",
  "type": "WAIT",
  "subtype": "MESSAGE",
  "sourceStepId": "send_command"
}
```

### TERMINAL

```json
{
  "id": "finish_complete",
  "type": "TERMINAL",
  "subtype": "COMPLETE",
  "result": {
    "status": "COMPLETE",
    "outcome": "REQUEST_COMPLETED"
  }
}
```

## Runtime result shapes

### `reduce(step, state, output)`

- applies only to `PROCESS`
- executable PROCESS writes `output` to `outputRef`
- ROUTE and SWITCH ignore `output`
- returns new `ProcessState`

### `effectResult`

```json
{
  "requestId": "req-001",
  "result": {},
  "error": null,
  "errorCode": null
}
```

Rules:
- `requestId` required
- `result` must be JSON-safe if present
- `error` must be JSON-safe if non-null
- `errorCode` must be non-empty string if present
- non-null `result` + non-null `error` is invalid

### `waitResult`

Same shape and validation rules as `effectResult`.

## Trace and `context.steps`

Minimal trace shape per step:

```json
{
  "status": "COMPLETED",
  "startedAt": "2026-04-09T10:00:00Z",
  "finishedAt": "2026-04-09T10:00:01Z",
  "failureCode": null,
  "reason": null
}
```

Stable fields:
- `status`
- `startedAt`
- `finishedAt`
- `failureCode`
- `reason`
- `selectedNextStepId` for ROUTE / SWITCH

`WAIT.startedAt` is set when the process enters waiting state and is preserved on `resume(...)`.

## Error contract

### Validation

```json
{
  "isValid": true,
  "errors": [],
  "warnings": []
}
```

Validation issue shape:

```json
{
  "code": "FLOW_WAIT_BRANCH_MISSING",
  "message": "WAIT.onTimeoutStepId is required",
  "path": "$.steps[\"wait_response\"].onTimeoutStepId",
  "details": {}
}
```

### Typed public errors

- `XCompileError`
- `XRuntimeError`

Stable runtime error families include:
- `FLOW_FLOW_MISMATCH`
- `FLOW_STEP_NOT_FOUND`
- `FLOW_STEP_MISMATCH`
- `FLOW_TERMINAL_MISUSED`
- `FLOW_REDUCE_INVALID_TYPE`
- `FLOW_APPLY_INVALID_TYPE`
- `FLOW_RESUME_INVALID_TYPE`
- `FLOW_PATH_NOT_RESOLVED`
- `FLOW_ROUTING_VALUE_INVALID`
- `FLOW_DECISION_NOT_RESOLVED`
- `FLOW_RESULT_SHAPE_INVALID`
- `FLOW_MIXED_RESULT`
- `FLOW_REQUEST_ID_MISSING`

Host infrastructure failures are not semantic `flows` errors until Host maps them into `effectResult` or `waitResult`.

## Compatibility and migration

- No legacy snapshot/runtime facade
- No subtype-less `PROCESS`
- No array-form `steps`
- No `RUNNING` status
- No `artefactId` on EFFECT
- External correlation contract uses only `requestId`
- No public `createProcessState(...)` in root package export

See [COMPATIBILITY.md](./COMPATIBILITY.md) and [docs/MIGRATION_GUIDE.md](./docs/MIGRATION_GUIDE.md).

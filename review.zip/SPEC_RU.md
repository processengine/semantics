# Спецификация `@processengine/flows`

## Назначение

`flows` — это runtime процессной семантики в ProcessEngine. Библиотека валидирует Flow DSL, подготавливает immutable `PreparedFlow`, нормализует текущий шаг и применяет переходы состояния процесса.

`flows` не исполняет runtime-модули, не делает Host side effects, не хранит state, не генерирует `requestId` и не владеет retry/scheduling.

## Публичный API

```ts
validateFlow(flow, options?) -> ValidationResult
prepareFlow(flow, options?)  -> PreparedFlow

plan(preparedFlow, state)                        -> NormalizedStep
reduce(step, state, output)                      -> ProcessState
apply(preparedFlow, state, stepId, effectResult) -> ProcessState
resume(preparedFlow, state, stepId, waitResult)  -> ProcessState
```

`validateFlow(...)` не бросает исключения для обычных ошибок DSL.  
`prepareFlow(...)` бросает `XCompileError`.  
Runtime-методы бросают `XRuntimeError`.

## Граница между `flows`, `process` и Host

- `flows` владеет DSL-семантикой, `PreparedFlow`, `plan`, `reduce`, `apply`, `resume`
- `process` исполняет только исполнимые `PROCESS`-шаги: `RULES`, `MAPPINGS`, `DECISIONS`
- Host владеет persistence, execution loop, side effects, transport, recovery, `requestId`

Host не должен вручную резолвить `inputRef`, `factRef` и логику SWITCH.

## Flow DSL

### Root shape

```json
{
  "id": "request.processing",
  "version": "2026-04-09",
  "entryStepId": "validate_input",
  "steps": {
    "validate_input": { "...": "..." }
  }
}
```

Правила:
- `id` обязателен
- `version` обязателен
- `entryStepId` должен ссылаться на существующий шаг
- `steps` должен быть непустым объектом
- ключ объекта должен совпадать с `step.id`

### Семейства шагов

| type | subtype |
|------|---------|
| `PROCESS` | `RULES`, `MAPPINGS`, `DECISIONS`, `ROUTE`, `SWITCH` |
| `EFFECT` | `COMMAND`, `CALL` |
| `WAIT` | `MESSAGE` |
| `TERMINAL` | `COMPLETE`, `FAIL` |

Шагов без subtype в публичном контракте нет.

### Исполнимый PROCESS

Обязательные поля:
- `id`
- `type: "PROCESS"`
- `subtype`
- `artefactId`
- `inputRef`
- `outputRef`
- `nextStepId`

Разрешённые зоны для `outputRef`:
- `$.context.checks...`
- `$.context.facts...`
- `$.context.decisions...`

Предметная конвенция:
- `RULES` пишут в `context.checks`
- `MAPPINGS` пишут в `context.facts`
- `DECISIONS` пишут в `context.decisions`

### ROUTE

Обязательные поля:
- `factRef`
- `cases`
- `defaultNextStepId`

Runtime-семантика:
- читает `factRef`
- отсутствующий путь — runtime violation
- scalar-значение нормализуется в case key
- object/array для маршрутизации — runtime violation

### SWITCH

Обязательные поля:
- `decisionSetId`
- `cases`
- `defaultNextStepId`

Runtime-семантика:
- читает `context.decisions[decisionSetId].outcome`
- отсутствующий decision record или `outcome` — runtime violation

### EFFECT

Обязательные поля:
- `id`
- `type: "EFFECT"`
- `subtype`
- `operationId`
- `inputRef`
- `nextStepId`

Опциональные:
- `onErrorStepId`
- `onTimeoutStepId`

`operationId` — это Host dispatch identifier. Это не `artefactId`.

### WAIT

`WAIT/MESSAGE` — единственная каноническая форма wait-step.

Обязательные поля:
- `id`
- `type: "WAIT"`
- `subtype: "MESSAGE"`
- `sourceStepId`
- `nextStepId`
- `onErrorStepId`
- `onTimeoutStepId`

`sourceStepId` должен ссылаться на EFFECT step.

### TERMINAL

Обязательные поля:
- `id`
- `type: "TERMINAL"`
- `subtype`
- `result`

`result.status` должен совпадать с TERMINAL subtype.

## Prepared Flow

`prepareFlow(...)` возвращает `PreparedFlow`.

Гарантии:
- отдельный артефакт, не raw flow
- compile/prepare-checked
- immutable
- JSON-safe / transport-safe
- готов для `plan`, `reduce`, `apply`, `resume`

Внутренняя структура `PreparedFlow` implementation-private и не является нормативной частью контракта.

## Process State

Каноническая root-shape:

```json
{
  "processId": "proc_001",
  "id": "request.processing",
  "status": "ACTIVE",
  "currentStepId": "validate_input",
  "currentStepType": "PROCESS",
  "currentStepSubtype": "RULES",
  "context": {
    "input": {},
    "checks": {},
    "facts": {},
    "decisions": {},
    "steps": {},
    "effects": {}
  },
  "history": [],
  "result": null,
  "meta": {}
}
```

Статусы:
- `ACTIVE`
- `WAITING`
- `COMPLETE`
- `FAIL`

Терминальный процесс нельзя продвигать дальше.

## Normalized steps

### Исполнимый PROCESS

```json
{
  "id": "validate_input",
  "type": "PROCESS",
  "subtype": "RULES",
  "artefactId": "process.validate",
  "input": {}
}
```

### ROUTE

```json
{
  "id": "route_validation",
  "type": "PROCESS",
  "subtype": "ROUTE",
  "selectedNextStepId": "send_command"
}
```

### SWITCH

```json
{
  "id": "switch_review",
  "type": "PROCESS",
  "subtype": "SWITCH",
  "selectedNextStepId": "finish_complete"
}
```

### EFFECT

```json
{
  "id": "send_command",
  "type": "EFFECT",
  "subtype": "COMMAND",
  "operationId": "remote.submit",
  "input": {}
}
```

### WAIT

```json
{
  "id": "wait_response",
  "type": "WAIT",
  "subtype": "MESSAGE",
  "sourceStepId": "send_command"
}
```

### TERMINAL

```json
{
  "id": "finish_complete",
  "type": "TERMINAL",
  "subtype": "COMPLETE",
  "result": {
    "status": "COMPLETE",
    "outcome": "REQUEST_COMPLETED"
  }
}
```

## Runtime result shapes

### `reduce(step, state, output)`

- применяется только к `PROCESS`
- исполнимый PROCESS пишет `output` в `outputRef`
- ROUTE и SWITCH игнорируют `output`
- возвращает новый `ProcessState`

### `effectResult`

```json
{
  "requestId": "req-001",
  "result": {},
  "error": null,
  "errorCode": null
}
```

Правила:
- `requestId` обязателен
- `result` должен быть JSON-safe, если присутствует
- `error` должен быть JSON-safe, если non-null
- `errorCode` должен быть непустой строкой, если присутствует
- non-null `result` + non-null `error` одновременно — invalid

### `waitResult`

Та же shape и те же правила, что у `effectResult`.

## Trace и `context.steps`

Минимальная trace-shape на шаг:

```json
{
  "status": "COMPLETED",
  "startedAt": "2026-04-09T10:00:00Z",
  "finishedAt": "2026-04-09T10:00:01Z",
  "failureCode": null,
  "reason": null
}
```

Стабильные поля:
- `status`
- `startedAt`
- `finishedAt`
- `failureCode`
- `reason`
- `selectedNextStepId` для ROUTE / SWITCH

`WAIT.startedAt` выставляется при входе в ожидание и сохраняется при `resume(...)`.

## Error contract

### Validation

```json
{
  "isValid": true,
  "errors": [],
  "warnings": []
}
```

Validation issue shape:

```json
{
  "code": "FLOW_WAIT_BRANCH_MISSING",
  "message": "WAIT.onTimeoutStepId is required",
  "path": "$.steps[\"wait_response\"].onTimeoutStepId",
  "details": {}
}
```

### Typed public errors

- `XCompileError`
- `XRuntimeError`

Стабильные runtime error families:
- `FLOW_FLOW_MISMATCH`
- `FLOW_STEP_NOT_FOUND`
- `FLOW_STEP_MISMATCH`
- `FLOW_TERMINAL_MISUSED`
- `FLOW_REDUCE_INVALID_TYPE`
- `FLOW_APPLY_INVALID_TYPE`
- `FLOW_RESUME_INVALID_TYPE`
- `FLOW_PATH_NOT_RESOLVED`
- `FLOW_ROUTING_VALUE_INVALID`
- `FLOW_DECISION_NOT_RESOLVED`
- `FLOW_RESULT_SHAPE_INVALID`
- `FLOW_MIXED_RESULT`
- `FLOW_REQUEST_ID_MISSING`

Host infrastructure failures не являются semantic errors `flows`, пока Host не преобразовал их в `effectResult` или `waitResult`.

## Совместимость и миграция

- Нет legacy snapshot/runtime facade
- Нет subtype-less `PROCESS`
- Нет array-form `steps`
- Нет статуса `RUNNING`
- Нет `artefactId` на EFFECT
- Во внешнем runtime contract используется только `requestId`
- Нет публичного `createProcessState(...)` в root export пакета

См. [COMPATIBILITY.md](./COMPATIBILITY.md) и [docs/MIGRATION_GUIDE.md](./docs/MIGRATION_GUIDE.md).
